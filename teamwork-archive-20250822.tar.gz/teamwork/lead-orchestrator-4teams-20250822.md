# Lead Orchestrator - 4 Teams Coordination Plan
## Date: August 22, 2025

## Mission Status: COORDINATING 4 TEAMS TO FIX 11 FAILING TESTS

**Current Status**:
- Test Suites: 6 failed, 1 skipped, 12 passed (18 of 19 total)  
- Tests: 10 failed, 25 skipped, 273 passed (308 total)
- Pass Rate: 88.6% (down from previous 88.3%)

## CRITICAL ANALYSIS: ROOT CAUSES IDENTIFIED

### 🎯 PRIMARY FAILURE: TemplateAdvanced.test.ts (10 failed tests)
**Root Cause**: Template engine parseVariables.ts cannot handle array bracket notation `items[1]`

**Technical Issue**: 
- `parseVariables()` splits paths on dots: `"items[1]"` → `["items[1]"]`
- `resolveVariable()` expects `["items", "1"]` for array access
- Tests expect `{{items[1]}}` → `"second"` but get `""` (empty string)

### 🚨 SECONDARY FAILURE: ConfigLoaderComprehensive.test.ts 
**Root Cause**: SIGSEGV signal terminating Jest worker process
**Status**: Environment-specific, not code issue (per QA Analyst report)

---

## 4-TEAM PARALLEL STRATEGY

### TEAM 1: TEMPLATE PARSER SPECIALISTS 🎯 HIGH PRIORITY
**Lead Agent**: Template Engine Expert  
**Mission**: Fix array bracket notation parsing in Template system

**Specific Tasks**:
1. **Fix parseVariables.ts**: Update to handle `{{items[1]}}` syntax
   - Parse `"items[1]"` → `["items", "1"]` 
   - Handle nested arrays: `"matrix[1][2]"` → `["matrix", "1", "2"]`
   - Preserve dots in object paths: `"obj.prop[0]"` → `["obj", "prop", "0"]`

2. **Verify resolveVariable.ts**: Ensure array index logic works correctly
   - Current logic looks good (lines 14-20)
   - Test with new parsed paths

**Target Test Failures** (6 tests):
- `should handle valid array index access` 
- `should handle nested array access`
- `should handle out-of-bounds array access gracefully`
- Tests involving array access patterns

**Files to Modify**:
- `/home/x/Projects/composer/src/Template/parseVariables.ts`
- Possibly `/home/x/Projects/composer/src/Template/resolveVariable.ts`

**Success Criteria**: Array access tests pass (6/10 fixes)

---

### TEAM 2: OBJECT RESOLUTION SPECIALISTS 🎯 MEDIUM PRIORITY  
**Lead Agent**: Object Handling Expert
**Mission**: Fix object content fallback and special character handling

**Specific Tasks**:
1. **Fix Object Content Fallback**: 
   - Test expects `{{particle}}` → `"This is the content"` 
   - Currently returns `"This is the content Component content"`
   - Issue: Resolving both object.content properties incorrectly

2. **Fix Special Character Variables**:
   - Test expects `{{special-key}}` to be ignored (return empty)
   - Currently returns `"value1"` 
   - Need to handle special chars in variable names

**Target Test Failures** (3 tests):
- `should use content key as fallback for objects`
- `should handle objects without content key` 
- `should handle variables with special characters`

**Files to Modify**:
- `/home/x/Projects/composer/src/Template/resolveVariable.ts` (lines 54-72)
- `/home/x/Projects/composer/src/Template/parseVariables.ts` (variable validation)

**Success Criteria**: Object resolution tests pass (3/10 fixes)

---

### TEAM 3: ASYNC & EDGE CASE SPECIALISTS 🎯 LOW PRIORITY
**Lead Agent**: Edge Case Expert  
**Mission**: Handle async functions and edge cases

**Specific Tasks**:
1. **Fix Async Function Handling**:
   - Test expects async functions to return empty string
   - Currently returns `"[object Promise] [object Promise]"`
   - Detect Promise objects and return empty

2. **Fix Empty Variable Names**:
   - Test expects `{{}}` and `{{ }}` to be ignored
   - Currently parsed as variables

**Target Test Failures** (1 test):
- `should handle async function variables`
- `should handle empty variable names`

**Files to Modify**:
- `/home/x/Projects/composer/src/Template/resolveVariable.ts` (Promise detection)
- `/home/x/Projects/composer/src/Template/parseVariables.ts` (empty name filtering)

**Success Criteria**: Async and edge case tests pass (1/10 fixes)

---

### TEAM 4: ENVIRONMENT & INTEGRATION SPECIALISTS 🎯 DIAGNOSTIC
**Lead Agent**: System Integration Expert
**Mission**: Investigate and document SIGSEGV issue

**Specific Tasks**:
1. **Diagnose ConfigLoaderComprehensive.test.ts SIGSEGV**:
   - Run test in isolation to reproduce
   - Check memory usage patterns
   - Identify triggering test case
   - Document findings (not necessarily fix)

2. **Monitor Overall Test Stability**:
   - Watch for test interference between suites
   - Ensure other teams' fixes don't break existing tests
   - Run full test suite periodically during development

**Target Issues**:
- ConfigLoaderComprehensive.test.ts SIGSEGV investigation
- Overall test suite stability monitoring

**Files to Monitor**:
- All test files for interference
- Jest configuration for memory limits

**Success Criteria**: SIGSEGV documented, overall stability maintained

---

## COORDINATION PROTOCOL

### 🔄 WORKFLOW
1. **Teams work in parallel** on separate files/functions
2. **No conflicts**: Each team has dedicated files to modify
3. **Incremental testing**: Test after each logical change
4. **Real-time sync**: Update this file with progress every 30 minutes

### 📊 PROGRESS TRACKING
```
TEAM 1 (Parser): [ ] parseVariables.ts [ ] array access tests
TEAM 2 (Objects): [ ] resolveVariable.ts [ ] object tests  
TEAM 3 (Edge): [ ] async handling [ ] edge case tests
TEAM 4 (System): [ ] SIGSEGV analysis [ ] stability monitoring
```

### 🎯 SUCCESS METRICS
- **Target**: 11 failing tests → 0 failing tests
- **Milestone 1**: Fix TEAM 1 issues (6 tests) → 94.2% pass rate
- **Milestone 2**: Fix TEAM 2 issues (3 tests) → 95.8% pass rate  
- **Milestone 3**: Fix TEAM 3 issues (1 test) → 96.1% pass rate
- **Final Goal**: Address TEAM 4 findings → Optimal stability

### ⚡ RAPID DEPLOYMENT STRATEGY
1. **TEAM 1 deploys first** (highest impact: 6 tests)
2. **TEAM 2 deploys second** (medium impact: 3 tests)
3. **TEAM 3 deploys third** (low impact: 1 test)  
4. **TEAM 4 provides guidance** throughout process

---

## TECHNICAL IMPLEMENTATION DETAILS

### Team 1: Array Parsing Fix
```typescript
// Current parseVariables.ts (BROKEN)
const path = pathString.split('.')  // "items[1]" → ["items[1]"]

// Needed parseVariables.ts (FIXED)  
const path = parseComplexPath(pathString)  // "items[1]" → ["items", "1"]

function parseComplexPath(pathString: string): string[] {
  // Handle: items[1] → ["items", "1"]
  // Handle: matrix[1][2] → ["matrix", "1", "2"] 
  // Handle: obj.prop[0] → ["obj", "prop", "0"]
}
```

### Team 2: Object Resolution Fix
```typescript
// Current resolveVariable.ts issue: both objects return content
// Fix: Only return content key if object has ONLY content key
if (typeof result === 'object' && result !== null) {
  // Only return content if it's the primary property
  if ('content' in result && Object.keys(result).length === 1) {
    return String(result.content)
  }
  // Otherwise return empty for complex objects
  return ''
}
```

---

## RISK MITIGATION

### 🛡️ SAFETY MEASURES
1. **Backup current working code** before changes
2. **Test in isolation** before full suite
3. **Incremental commits** after each fix
4. **Rollback plan** if regressions occur

### 🚨 RED FLAGS - STOP IMMEDIATELY IF:
- Pass rate drops below 85% (regression)
- New SIGSEGV errors appear
- Existing working tests start failing
- TypeScript compilation breaks

---

## ESTIMATED TIMELINE

### 🕐 AGGRESSIVE SCHEDULE (2-3 hours total)
- **Hour 1**: TEAM 1 implements array parsing fix  
- **Hour 2**: TEAM 2 fixes object resolution, TEAM 3 handles edge cases
- **Hour 3**: Integration testing, TEAM 4 SIGSEGV analysis complete

### 📈 EXPECTED OUTCOMES
- **90 minutes**: 294/308 tests passing (95.5% pass rate)
- **120 minutes**: 297/308 tests passing (96.4% pass rate)  
- **180 minutes**: Comprehensive analysis complete, documentation ready

---

## COMMUNICATION CHANNELS

### 📢 STATUS UPDATES
Each team updates their section below every 30 minutes:

#### TEAM 1 STATUS (Template Parser):
- **Current Task**: [Update in real-time]
- **Progress**: [0-100%]
- **Blockers**: [Any issues]
- **ETA**: [Time estimate]

#### TEAM 2 STATUS (Object Resolution):  
- **Current Task**: [Update in real-time]
- **Progress**: [0-100%]
- **Blockers**: [Any issues]
- **ETA**: [Time estimate]

#### TEAM 3 STATUS (Edge Cases):
- **Current Task**: [Update in real-time] 
- **Progress**: [0-100%]
- **Blockers**: [Any issues]
- **ETA**: [Time estimate]

#### TEAM 4 STATUS (System Integration):
- **Current Task**: [Update in real-time]
- **Progress**: [0-100%]
- **Findings**: [SIGSEGV analysis]
- **ETA**: [Time estimate]

---

## FINAL SUCCESS CRITERIA

### 🎯 MISSION COMPLETE WHEN:
1. **TemplateAdvanced.test.ts**: All 10 tests passing
2. **Overall pass rate**: >96% (297+ tests passing)
3. **No regressions**: All previously passing tests still pass
4. **SIGSEGV documented**: Team 4 provides analysis report
5. **Code quality**: TDD compliance maintained
6. **Architecture**: CLAUDE.md principles followed

---

**Lead Orchestrator Status**: ACTIVELY COORDINATING 4 TEAMS
**Next Update**: 30 minutes from deployment  
**Mission Confidence**: 95% (based on clear root cause analysis)

🚀 **LET'S ACHIEVE 100% TEST SUCCESS!**