# Detailed Coverage Gap Analysis for @composer

**Current Coverage:** 67.43% statements, 60.54% branches, 56.09% functions, 66.78% lines

**Target:** 100% coverage across all metrics

## Executive Summary

The coverage analysis reveals significant gaps across all major components. The main uncovered areas are:

1. **Error handling paths** (branches: 60.54% → 100% = 39.46% gap)
2. **Edge case functionality** (functions: 56.09% → 100% = 43.91% gap)  
3. **Platform-specific code paths** (largest uncovered block: lines 1515-1699)
4. **Configuration loading edge cases**
5. **File format processing variations**

## Priority 1: Critical Uncovered Functions (High Impact)

### ConfigLoader Edge Cases
**Lines: 1232-1249** - JavaScript module loading fallback
```javascript
// Uncovered: require() fallback when import() fails
try {
  delete require.cache[path.resolve(targetPath)];
  const requireResult = require(path.resolve(targetPath));
  // Lines 1239-1243 completely uncovered
} catch (requireErr) {
  throw new Error(`Failed to load config file: ${targetPath}\n${err.message}`);
}
```
**Test Needed:** Config loading with CommonJS modules that fail import()

### Data Loading Format Variations  
**Lines: 102-117** - Markdown frontmatter parsing
```javascript
// Uncovered: Markdown files with frontmatter
const frontmatterMatch = content.match(/^---\n([\s\S]*?)\n---\n([\s\S]*)$/);
if (frontmatterMatch) {
  // Lines 104-108 uncovered
  const frontmatter = yaml.load(frontmatterMatch[1]) || {};
  parsedData = {
    ...typeof frontmatter === "object" && frontmatter !== null ? frontmatter : {},
    content: frontmatterMatch[2].trim()
  };
} else {
  parsedData = { content: content.trim() }; // Line 110 uncovered
}
```
**Test Needed:** Data files with YAML frontmatter and edge cases

### Template Variable Error Handling
**Lines: 203-207** - Function execution error handling
```javascript
// Uncovered: Function variables that throw errors
if (typeof result === "function") {
  try {
    return String(result());
  } catch (error) {
    console.warn(`Error calling function ${variable.path.join(".")}: ${error}`); // Line 206 uncovered
    return "";
  }
}
```
**Test Needed:** Template variables that are functions throwing errors

## Priority 2: Platform Strategy Implementations (Medium-High Impact)

### Platform Detection and Strategy Creation
**Lines: 1515-1699** - All platform-specific strategies largely uncovered
- **BunStrategy:** Lines 1705-1761 (95% uncovered)
- **UnixStrategy:** Lines 1764-1803 (90% uncovered)  
- **WindowsStrategy:** Lines 1806-1860 (95% uncovered)

**Critical Missing Tests:**
```javascript
// Platform capabilities detection
getCapabilities() // Line 1517-1542 uncovered
getPaths() // Line 1544-1567 uncovered  
executeCommand() // Line 1598-1608 uncovered
hasCommand() // Line 1616-1622 uncovered
hasPackage() // Line 1624-1630 uncovered
```

**Test Needed:** Platform-specific functionality across Node.js, Bun, Unix, Windows

### Directory Resolution Methods
**Lines: 1580-1594** - App-specific directory resolution
```javascript
// Uncovered: Application directory resolution
resolveDataDir(appName) // Line 1580-1583
resolveConfigDir(appName) // Line 1584-1587  
resolveCacheDir(appName) // Line 1588-1591
resolveTempDir(appName) // Line 1592-1594
```

## Priority 3: BuildPipeline Complex Logic (Medium Impact)

### Output Format Processors
**Lines: 873-987** - Advanced output formatting
- **formatAsHtml:** Lines 875-900 (Template options, CSS injection)
- **formatAsXml:** Lines 931-943 (XML generation from objects)
- **formatAsCsv:** Lines 946-970 (CSV with custom separators, quoting)
- **objectToXml:** Lines 973-987 (Recursive XML conversion)

**Test Needed:** 
- HTML generation with custom CSS, scripts, metadata
- XML output with complex nested objects
- CSV with custom delimiters, quote handling, headers

### Complex Target Resolution  
**Lines: 990-1048** - Dynamic target generation
```javascript
// Uncovered: Dynamic target patterns
if (targetConfig.pattern && targetConfig.forEach) {
  return await this.generateDynamicTargets(targetConfig, result); // Lines 991-992
}

// Uncovered: Conditional targets
if (targetConfig.condition && targetConfig.target) {
  const shouldGenerate = await this.evaluateCondition(targetConfig.condition, result);
  // Lines 995-1000 uncovered
}
```

**Test Needed:** Build outputs with dynamic patterns and conditions

### Template Rendering in Targets
**Lines: 1002-1008** - Template-based target paths
```javascript
// Uncovered: Template rendering for target paths
if (targetConfig.template) {
  const targetPath = await this.renderTemplate(targetConfig.template, result);
  return [{
    path: targetPath,
    content: targetConfig.content,
    options: targetConfig.options
  }];
}
```

## Priority 4: Error Handling and Edge Cases (Medium Impact)

### Import Resolution Error Paths
**Lines: 451, 470, 507** - Import parsing error handling
```javascript
// Uncovered: YAML/JSON parsing failures
} catch (error) {
  return []; // Lines 451, 470 - Silent failure handling
}

// Uncovered: Invalid import configuration  
throw new Error(`Invalid import configuration: ${JSON.stringify(imp)}`); // Line 507
```

### File System Error Handling
**Lines: 709-710, 748-753** - File loading and regex pattern failures
```javascript
// Uncovered: File loading failures
} catch (error) {
  console.warn(`Failed to load ${relativePath}:`, error); // Line 709
  continue;
}

// Uncovered: Directory walking errors in regex patterns
} catch (error) {
  // Line 800 - Silent error in directory traversal
}
```

### Configuration Validation Errors
**Lines: 1447, 1454** - Watch path filtering and error handling
```javascript
// Uncovered: Path filtering in watch setup
const paths = [
  this.options.dataPath,
  this.options.templatesPath,
  // ... other paths
].filter((p) => p); // Line 1442 - Path filtering logic

// Uncovered: Watch callback error handling  
if (callback) {
  callback(outputs); // Line 1454
}
```

## Priority 5: Branch Coverage Gaps (Lower Impact)

### Conditional Logic Branches
**Lines: 238, 282, 311, 317, 323, 329, 335, 341, 347** - Method delegation branches
- Template render with/without context
- BuildPipeline processor registration
- Various conditional method calls

### Array vs Object Handling
**Lines: 181-185, 215-221** - Variable resolution type checking
```javascript
// Uncovered: Array index access validation
if (Array.isArray(current) && /^\d+$/.test(segment)) {
  const index = parseInt(segment, 10);
  if (index >= 0 && index < current.length) {
    current = current[index]; // Line 183 uncovered
  } else {
    return null; // Line 185 uncovered
  }
}

// Uncovered: Object property fallback logic
const contentKeys = ["content", "value", "text", "data"];
for (const key of contentKeys) {
  if (key in result) {
    return String(result[key]); // Line 218 uncovered
  }
}
```

## Implementation Strategy

### Phase 1: High-Impact Functions (Week 1)
1. **ConfigLoader.test.js** - Add CommonJS fallback testing
2. **Template.test.js** - Add function variable error handling  
3. **Composer.test.js** - Add markdown frontmatter parsing
4. **BuildPipeline.test.js** - Add complex output formatting

### Phase 2: Platform Coverage (Week 2)  
1. **Platform.test.js** - Mock different runtime environments
2. **PlatformStrategies.test.js** - Test Bun, Unix, Windows strategies
3. **PlatformCapabilities.test.js** - Test capability detection

### Phase 3: Edge Cases (Week 3)
1. **ImportResolver.test.js** - Add error path testing
2. **BuildPipeline.test.js** - Add dynamic target generation
3. **FileSystem.test.js** - Add error handling scenarios

### Phase 4: Branch Coverage (Week 4)
1. Review all conditional branches
2. Add parameterized tests for different code paths  
3. Final coverage validation and reporting

## Expected Impact

Implementing all identified tests should achieve:
- **Statements:** 67.43% → 100% (+32.57%)
- **Branches:** 60.54% → 100% (+39.46%)  
- **Functions:** 56.09% → 100% (+43.91%)
- **Lines:** 66.78% → 100% (+33.22%)

## Files Requiring New Test Coverage

1. `test/ConfigLoader.comprehensive.test.js` - Lines 1232-1249
2. `test/Template.variables.test.js` - Lines 203-207, 215-221  
3. `test/Composer.data.test.js` - Lines 102-117
4. `test/Platform.strategies.test.js` - Lines 1515-1699
5. `test/BuildPipeline.formats.test.js` - Lines 873-987
6. `test/BuildPipeline.targets.test.js` - Lines 990-1048
7. `test/ImportResolver.errors.test.js` - Lines 451, 470, 507
8. `test/FileSystem.errors.test.js` - Lines 709-710, 748-753

---

**Analysis completed:** 2025-08-22  
**Next action:** Prioritize Phase 1 implementation for maximum coverage impact